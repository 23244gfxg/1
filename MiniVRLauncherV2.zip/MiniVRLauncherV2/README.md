# MiniVR Launcher v2

手机 + VR 盒子 = 迷你一体机。纯 Java / OpenGL ES 2.0，**零第三方依赖**。

v2 相对 v1 的三处升级：

1. **② 内置球面 360/180 播放器**：看片不再跳系统播放器。VR 内多了一屏「本地视频库」，选中后由 `MediaPlayer → SurfaceTexture → GL_TEXTURE_EXTERNAL_OES → 球面网格` 直接渲染，左右眼各自取 SBS/TB 的对应半区。
2. **摄像头手部识别**：手掌移动驱动准星，张开后**握拳 = 点击**；检测到手时自动从凝视模式切换过去。
3. **去 SDK 化**：丢掉已停更的 Google VR SDK，改用 Android 原生 `SensorManager + GLSurfaceView + Camera2/Camera1`，无 GMS / ARCore / NDK / RenderScript 依赖。

---

## ⚠️ 关于「打包成 APK」

**本仓库是完整可编译源码，故意不含 `.apk` 二进制。**
生成 APK 需要 JDK 17 + Android SDK（platform-34 / build-tools 34.0.0）+ Gradle；当前交付环境只有 JRE 11、无 Android SDK，且 Maven / Google 仓库被网络策略拦截（403），因此无法在这里产出真实可安装的 APK。给一个改名的假包只会浪费你时间。

三条路径，按省事程度排序：

| 路径 | 操作 | 产出 |
|---|---|---|
| **A. 云编译（推荐）** | 把整个目录 push 到 GitHub → Actions → `build-apk` → 下载 artifact | `app-debug.apk`，零本地配置 |
| **B. Android Studio** | 打开本目录 → Sync（自动补 wrapper.jar）→ Run / Build APK | 直接装到手机 |
| **C. 命令行** | 装好 JDK17 + Android SDK → `./build_apk.sh` | 根目录 `MiniVRLauncher-debug.apk` |

云编译的配置已放在 `.github/workflows/build-apk.yml`：装 JDK17、装 SDK 包、拉 Gradle 8.2、`gradle assembleDebug`、上传 APK。`build_apk.sh` 会自动检测 JDK / `ANDROID_HOME`、补装 SDK 包、生成 `local.properties`、编译并复制产物。

> 因为 `dependencies {}` 是空的，Sync 阶段不会去拉任何停更的 aar，云编译成功率很高。

---

## 功能与场景

```
LAUNCHER（6 宫格）
 ├─ 看片 → LIBRARY（MediaStore 最近 6 个视频，VR 内网格选择，不跳系统）
 │           └─ VIDEO（球面播放 + 4 个角落悬浮按钮：返回/播放/格式/翻转）
 ├─ 上网 / 相册 → 系统应用（这两个仍是 2D，属 Cardboard 生态固有边界）
 ├─ 时钟 → Toast
 ├─ 设置 → SETTINGS（回正 / 镜像 / 格式 / 手势开关 / 返回）
 └─ 关于
```

**输入**（`GazeInput` 把两种输入压成同一套「平面坐标 + 命中 + 触发」）：

- 凝视：盯住图标约 **1.2s** 触发，准星由橙转绿显示进度
- 手势：移动手掌移动准星，**握拳立即点击**，准星变蓝并多一圈掌心光环
- 检测到手自动切到手势模式，手离开 700ms 后自动退回凝视
- 一阶低通（0.82）压陀螺仪抖动；触发后 1.5s 冷却防连点；命中带迟滞防边缘反复清零

---

## 底层兼容设计（这是这版的重点）

| 项 | 做法 |
|---|---|
| 双目渲染 | `GLSurfaceView(GLES2)` + 两个 FBO + 一次全屏 pass 做透镜预畸变；**不用 GvrView** |
| 头部姿态 | `TYPE_GAME_ROTATION_VECTOR`（不依赖磁力计）→ 相对四元数 `q0⁻¹⊗q` → 旋转矩阵；用「相对零位」而非世界 ENU 轴，绕开各机型 `remapCoordinateSystem` 差异 |
| 摄像头 ≥21 | `Camera2 / YUV_420_888 / ImageReader`，按 `rowStride·pixelStride` 手动下采样 |
| 摄像头 <21 | 自动降级 `Camera1 / NV21`，`setPreviewCallbackWithBuffer` 双缓冲复用 |
| 肤色检测 | **直接在 YUV 色度通道 Cb/Cr 上判据**，不转 RGB、不用 RenderScript（API 31 已弃用、AGP8 移除） |
| 手部几何 | 3×3 开运算 → 4 邻域连通域 → 最大块质心 → 24 向径向采样估手指数 → 张开→握拳下降沿 |
| 线程 | 摄像头与检测跑 `HandlerThread`，结果用 `volatile` 快照发布给 GL 线程；GL 线程不做 IO |
| 权限 | `CAMERA` + `READ_MEDIA_VIDEO`(33+) / `READ_EXTERNAL_STORAGE`(≤32)，动态申请；拒绝摄像头只影响手势，凝视照常 |
| minSdk | **19**；targetSdk / compileSdk 34；无 NDK、无 GMS、无 Google Play 服务 |

### ⚠️ 手势的物理前提（必读）

手机塞进**封闭** VR 盒子时，后置摄像头被背板挡死、前置朝眼睛也看不见手 —— 这是硬件事实，不是软件能绕的。要用手势，必须满足其一：

- 拆掉盒子背板 / 用开放式手机支架，让**后置摄像头朝外**，手在手机前 20–50cm 挥动（透视式，CardboardXR 就是这么做的）
- 或把 `MainActivity.PREFER_FRONT_CAMERA` 改成 `true`（仅当你的盒子在前摄位置有开孔）
- 或外接 USB UVC 摄像头（需自行加 `UsbHost` + libuvc，本版未含）

没有这个前提，手势不会生效，但凝视模式完全可用。

---

## 视频格式

VR 内「格式」按钮循环切换，左右眼自动取对应半区：

| 格式 | 球面 | 说明 |
|---|---|---|
| `MONO_360` | 360° | 普通 2:1 等距柱状全景 |
| `SBS_360` | 360° | 左右 3D，左右眼各取画面左/右半 |
| `TB_360` | 360° | 上下 3D，左眼取上半、右眼取下半 |
| `MONO_180` | 前 180° | 半球网格，画面铺在前方 |
| `SBS_180` | 前 180° | 半球 + 左右分屏 |

`SphereMesh` 的 UV 设计让 **u=0.5 正对开机朝向 (-Z)**，所以视频正前方就是视线中心。若某片源左右反了，点「翻转」。

---

## 可调旋钮

| 位置 | 常量 | 默认 | 作用 |
|---|---|---|---|
| `GazeInput` | `LP` | 0.82 | 低通权重；0.9 更稳但跟手变钝 |
| `GazeInput` | `TRIGGER_FRAMES` | 72 | 凝视 1.2s；误触多调到 90 |
| `GazeInput` | `HAND_RANGE_X/Y` | 4.6 / 3.0 | 手掌画面坐标 → 面板平面的映射范围 |
| `StereoView` | `IPD / CONVERGENCE / fovDeg` | 0.064 / 2.0 / 95° | 瞳距、汇聚距离、视场角 |
| `StereoCompositor` | `K1 / K2` | 0.15 / 0.05 | 透镜预畸变；设为 0,0 即关闭（纯左右分屏） |
| `HandDetector` | `FW / FH` | 160×120 | 检测网格；调大更准但更耗 CPU |
| `HandTracker` | `FRAME_SKIP` | 3 | 每 3 帧算一次 |
| `HandDetector` | 肤色区间 | Cb 77–127 / Cr 133–173 | 深色皮肤或暖光下可放宽 Cr 上限 |

---

## 目录

```
app/src/main/java/com/minivr/launcher/
├── MainActivity.java        权限 / 生命周期
├── StereoView.java          GLES2 双目框架 + 传感器相对姿态 + off-axis 视锥
├── StereoCompositor.java    双 FBO + 透镜畸变合成
├── SphereMesh.java          球面网格（天空盒 / 视频球 / 180 半球共用）
├── Skybox.java              程序化星空纹理
├── VideoPlayer.java         MediaPlayer + OES 纹理 + 180/360·SBS/TB 格式
├── HandTracker.java         Camera2(≥21) / Camera1(<21) 双路径采集
├── HandDetector.java        YUV 色度肤色分割 + 连通域 + 握拳检测
├── GazeInput.java           凝视/手势统一输入 + 低通 + 命中 + 触发
├── LauncherRenderer.java    四屏状态机 + 绘制 + 动作
├── IconTexture.java         Canvas 运行时画图标/准星（零图片资源）
└── Gl.java                  GLES 工具
```

---

## 已知限制

- **没有 compositor / timewarp / late-latching**：延迟取决于手机屏幕与刷新率，别拿它跟一体机比晕不晕。
- 肤色检测对**深色皮肤、强暖光、复杂背景**敏感，是刻意选的零依赖代价。要更准：`HandDetector` 是独立类，换成一个 TFLite/MediaPipe 后端即可，其余代码不用动。
- 部分 ROM 的 `YUV_420_888` stride 有对齐差异，代码已做边界兜底；若手势框偏移，先打印 `rowStride/pixelStride` 核对。
- 手机陀螺仪会缓慢漂移，歪了就进「设置 → 回正」。
- 长时间播放的耗电与发热取决于手机；`FRAME_SKIP` 和 160×120 网格就是为此压的。
- 「上网 / 相册」仍会跳出 VR 模式，这是 Cardboard 类方案的固有边界。

## 下一步可选

- 把摄像头画面做成半透明透视背景（video see-through），手的位置可视化
- 蓝牙遥控器：`KEYCODE_DPAD_CENTER` 作为第三种输入源接进 `GazeInput`
- 接 TFLite 手部关键点模型替换肤色检测
