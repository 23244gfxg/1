#!/usr/bin/env bash
# 一键构建 debug APK。前提：本机已装 JDK 17 + Android SDK(platform 34 / build-tools 34)。
# 若环境不齐，请用 README 里的「GitHub Actions 云编译」路径，零本地配置直接拿 APK。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "==> 检查 JDK（AGP 8.1.4 需要 JDK 17）"
if ! command -v javac >/dev/null 2>&1; then
  echo "  ✗ 找不到 javac。请安装 JDK 17 并设置 JAVA_HOME 后重试。"
  exit 1
fi
javac -version

echo "==> 检查 Android SDK"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [ -z "$SDK" ] || [ ! -d "$SDK" ]; then
  echo "  ✗ 未设置 ANDROID_HOME / ANDROID_SDK_ROOT。"
  echo "    例：export ANDROID_HOME=\$HOME/Android/Sdk"
  exit 1
fi
echo "  SDK = $SDK"

if [ ! -d "$SDK/platforms/android-34" ] || [ ! -d "$SDK/build-tools/34.0.0" ]; then
  echo "==> 安装 platform / build-tools"
  "$SDK/cmdline-tools/latest/bin/sdkmanager" \
    "platforms;android-34" "build-tools;34.0.0" "platform-tools"
fi

echo "sdk.dir=$SDK" > local.properties

echo "==> 选择 Gradle"
GRADLE_CMD=""
if [ -f gradle/wrapper/gradle-wrapper.jar ] && [ -x ./gradlew ]; then
  GRADLE_CMD="./gradlew"
elif command -v gradle >/dev/null 2>&1; then
  GRADLE_CMD="gradle"
else
  echo "  ✗ 没有 gradlew.jar，也没有系统 gradle。"
  echo "    最简单：用 Android Studio 打开本目录（它会自动补齐 wrapper），点 Run 即出 APK。"
  echo "    或看 README 的 GitHub Actions 云编译路径。"
  exit 1
fi

echo "==> 编译"
$GRADLE_CMD assembleDebug --no-daemon --stacktrace

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ ! -f "$APK" ]; then
  echo "  ✗ 未找到产物：$APK"
  exit 1
fi
cp "$APK" "$ROOT/MiniVRLauncher-debug.apk"
echo ""
echo "✅ 完成：$ROOT/MiniVRLauncher-debug.apk"
echo "   安装：adb install -r MiniVRLauncher-debug.apk"
