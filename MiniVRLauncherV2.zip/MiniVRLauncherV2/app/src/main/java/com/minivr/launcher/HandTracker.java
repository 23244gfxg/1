package com.minivr.launcher;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 摄像头采集层：API>=21 走 Camera2(YUV_420_888)，API<21 或 Camera2 打开失败自动降级 Camera1(NV21)。
 *
 * 两条路径都下采样成 160x120 的 {Y, Cb, Cr} 交给 HandDetector，检测器与采集实现完全解耦。
 * 不依赖 ARCore / GMS / RenderScript / NDK，权限只有 CAMERA。
 *
 * ⚠️ 物理前提：手机塞进封闭 VR 盒子时后置摄像头会被背板挡死。
 *    必须拆掉背板、用开放式支架，或把 preferFront 打开（若盒子在前摄位置有开孔）。
 */
public class HandTracker {

    public interface Callback {
        void onGesture(HandDetector.Gesture g);
        void onStatus(String msg);
    }

    private static final int FRAME_SKIP = 3;   // 每 3 帧算一次，省 CPU
    private static final int MIN_W = 320, MIN_H = 240;

    private HandlerThread camThread;
    private Handler camHandler;
    private final HandDetector detector = new HandDetector();
    private final HandDetector.Frame frame = new HandDetector.Frame();
    private Callback callback;
    private volatile boolean running;
    private int tick;

    // Camera2
    private CameraDevice device;
    private CameraCaptureSession session;
    private ImageReader reader;

    // Camera1
    private Camera legacy;
    private SurfaceTexture dummy;

    @SuppressLint("MissingPermission")
    public void start(Context ctx, boolean preferFront, Callback cb) {
        this.callback = cb;
        if (running) return;
        running = true;
        camThread = new HandlerThread("MiniVR-Camera");
        camThread.start();
        camHandler = new Handler(camThread.getLooper());
        final Context app = ctx.getApplicationContext();
        camHandler.post(new Runnable() {
            @Override public void run() {
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        startCamera2(app, preferFront);
                        return;
                    } catch (Exception e) {
                        status("Camera2 不可用，降级 Camera1：" + e.getClass().getSimpleName());
                    }
                }
                try {
                    startCamera1(preferFront);
                } catch (Exception e) {
                    status("摄像头打不开：" + e.getMessage());
                }
            }
        });
    }

    public void stop() {
        running = false;
        Handler h = camHandler;
        if (h != null) {
            h.post(new Runnable() {
                @Override public void run() { closeCamera(); }
            });
        }
        HandlerThread t = camThread;
        if (t != null) t.quitSafely();
        camThread = null;
        camHandler = null;
        callback = null;
    }

    // ==================== Camera2 (API 21+) ====================

    @TargetApi(21)
    @SuppressLint("MissingPermission")
    private void startCamera2(Context ctx, boolean preferFront) throws CameraAccessException {
        CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
        if (cm == null) throw new IllegalStateException("no CameraManager");

        String picked = null;
        int want = preferFront ? CameraCharacteristics.LENS_FACING_FRONT
                               : CameraCharacteristics.LENS_FACING_BACK;
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics c = cm.getCameraCharacteristics(id);
            Integer facing = c.get(CameraCharacteristics.LENS_FACING);
            if (facing != null && facing == want) { picked = id; break; }
        }
        if (picked == null && cm.getCameraIdList().length > 0) {
            picked = cm.getCameraIdList()[0];
        }
        if (picked == null) throw new IllegalStateException("no camera");

        CameraCharacteristics c = cm.getCameraCharacteristics(picked);
        StreamConfigurationMap map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        if (map == null) throw new IllegalStateException("no stream map");
        Size chosen = pickSize(map.getOutputSizes(ImageFormat.YUV_420_888));
        if (chosen == null) throw new IllegalStateException("no YUV size");

        reader = ImageReader.newInstance(chosen.getWidth(), chosen.getHeight(),
                ImageFormat.YUV_420_888, 3);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader r) {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) return;
                    if ((tick++ % FRAME_SKIP) != 0) return;
                    if (!running) return;
                    fillFromYuv420(img);
                    emit(detector.detect(frame));
                } catch (Exception ignored) {
                } finally {
                    if (img != null) img.close();
                }
            }
        }, camHandler);

        cm.openCamera(picked, new CameraDevice.StateCallback() {
            @Override public void onOpened(CameraDevice d) {
                if (!running) { d.close(); return; }
                device = d;
                try {
                    final CaptureRequest.Builder b =
                            d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                    b.addTarget(reader.getSurface());
                    b.set(CaptureRequest.CONTROL_AF_MODE,
                            CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO);
                    d.createCaptureSession(Arrays.asList(reader.getSurface()),
                            new CameraCaptureSession.StateCallback() {
                                @Override public void onConfigured(CameraCaptureSession s) {
                                    if (!running) { s.close(); return; }
                                    session = s;
                                    try {
                                        s.setRepeatingRequest(b.build(), null, camHandler);
                                        status("手势追踪已启动 (Camera2)");
                                    } catch (Exception e) {
                                        status("预览启动失败：" + e.getMessage());
                                    }
                                }
                                @Override public void onConfigureFailed(CameraCaptureSession s) {
                                    status("Camera2 会话配置失败，降级 Camera1");
                                    closeCamera2Only();
                                    try { startCamera1(false); } catch (Exception ignored) {}
                                }
                            }, camHandler);
                } catch (Exception e) {
                    status("Camera2 请求失败：" + e.getMessage());
                }
            }
            @Override public void onDisconnected(CameraDevice d) { d.close(); device = null; }
            @Override public void onError(CameraDevice d, int error) {
                d.close();
                device = null;
                status("Camera2 error=" + error);
            }
        }, camHandler);
    }

    @TargetApi(21)
    private void fillFromYuv420(Image img) {
        Image.Plane[] p = img.getPlanes();
        ByteBuffer yb = p[0].getBuffer(), ub = p[1].getBuffer(), vb = p[2].getBuffer();
        int sw = img.getWidth(), sh = img.getHeight();
        int yRow = p[0].getRowStride(), yPix = p[0].getPixelStride();
        int uRow = p[1].getRowStride(), uPix = p[1].getPixelStride();
        int vRow = p[2].getRowStride(), vPix = p[2].getPixelStride();

        int k = 0;
        for (int j = 0; j < HandDetector.FH; j++) {
            int sy = j * sh / HandDetector.FH;
            int yBase = sy * yRow;
            int cuRow = (sy >> 1) * uRow;
            int cvRow = (sy >> 1) * vRow;
            for (int i = 0; i < HandDetector.FW; i++, k++) {
                int sx = i * sw / HandDetector.FW;
                frame.y[k] = get(yb, yBase + sx * yPix);
                int cx = sx >> 1;
                frame.cb[k] = get(ub, cuRow + cx * uPix);
                frame.cr[k] = get(vb, cvRow + cx * vPix);
            }
        }
    }

    private static byte get(ByteBuffer b, int idx) {
        if (idx < 0 || idx >= b.limit()) return 0;
        return b.get(idx);
    }

    @TargetApi(21)
    private static Size pickSize(Size[] sizes) {
        if (sizes == null || sizes.length == 0) return null;
        Size best = null;
        int bestArea = Integer.MAX_VALUE;
        for (Size s : sizes) {
            int a = s.getWidth() * s.getHeight();
            if (s.getWidth() >= MIN_W && s.getHeight() >= MIN_H && a < bestArea) {
                best = s; bestArea = a;
            }
        }
        if (best == null) {
            for (Size s : sizes) {
                int a = s.getWidth() * s.getHeight();
                if (a < bestArea) { best = s; bestArea = a; }
            }
        }
        return best;
    }

    // ==================== Camera1 兜底 (API < 21) ====================

    @SuppressWarnings("deprecation")
    private void startCamera1(boolean preferFront) {
        int want = preferFront ? Camera.CameraInfo.CAMERA_FACING_FRONT
                               : Camera.CameraInfo.CAMERA_FACING_BACK;
        int id = -1, fallback = -1;
        Camera.CameraInfo info = new Camera.CameraInfo();
        for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
            Camera.getCameraInfo(i, info);
            if (fallback < 0) fallback = i;
            if (info.facing == want) { id = i; break; }
        }
        if (id < 0) id = fallback;
        if (id < 0) throw new IllegalStateException("no camera");

        Camera cam = Camera.open(id);
        legacy = cam;
        Camera.Parameters p = cam.getParameters();
        p.setPreviewFormat(ImageFormat.NV21);
        Camera.Size best = pickLegacySize(p.getSupportedPreviewSizes());
        final int pw, ph;
        if (best != null) {
            pw = best.width; ph = best.height;
            p.setPreviewSize(pw, ph);
        } else {
            pw = 320; ph = 240;
        }
        cam.setParameters(p);

        try {
            dummy = new SurfaceTexture(7);   // 不需要真渲染，只为满足部分 ROM 的 preview 要求
            cam.setPreviewTexture(dummy);
        } catch (Exception e) {
            try { cam.setPreviewDisplay(null); } catch (Exception ignored) {}
        }

        // 用 withBuffer + 双缓冲复用，避免每帧 new byte[] 造成 GC 抖动。
        // 无论是否跳帧都必须把 buffer 还回去，否则预览会在几帧后停住。
        cam.setPreviewCallbackWithBuffer(new Camera.PreviewCallback() {
            @Override public void onPreviewFrame(final byte[] data, Camera camera) {
                if (data == null) return;
                if ((tick++ % FRAME_SKIP) != 0 || !running) {
                    camera.addCallbackBuffer(data);
                    return;
                }
                final byte[] copy = data.clone();   // data 会被复用，必须拷贝后再跨线程
                Handler h = camHandler;
                if (h != null) {
                    h.post(new Runnable() {
                        @Override public void run() {
                            if (!running) return;
                            fillFromNv21(copy, pw, ph);
                            emit(detector.detect(frame));
                        }
                    });
                }
                camera.addCallbackBuffer(data);
            }
        });
        int bufLen = pw * ph * 3 / 2;
        cam.addCallbackBuffer(new byte[bufLen]);
        cam.addCallbackBuffer(new byte[bufLen]);
        cam.startPreview();
        status("手势追踪已启动 (Camera1)");
    }

    /** NV21 = Y 平面 + 交织 VU（每 2x2 块：V 在前、U 在后）。 */
    private void fillFromNv21(byte[] data, int w, int h) {
        int base = w * h;
        int k = 0;
        for (int j = 0; j < HandDetector.FH; j++) {
            int sy = j * h / HandDetector.FH;
            int row = sy * w;
            int cRow = base + (sy >> 1) * w;
            for (int i = 0; i < HandDetector.FW; i++, k++) {
                int sx = i * w / HandDetector.FW;
                frame.y[k] = safe(data, row + sx);
                int ci = cRow + (sx & ~1);
                // NV21 交织顺序是 V(Cr) 在前、U(Cb) 在后，两者均为无符号 0..255（中心 128）
                frame.cr[k] = safe(data, ci);
                frame.cb[k] = safe(data, ci + 1);
            }
        }
    }

    private static byte safe(byte[] a, int i) {
        return (i >= 0 && i < a.length) ? a[i] : 0;
    }

    @SuppressWarnings("deprecation")
    private static Camera.Size pickLegacySize(List<Camera.Size> sizes) {
        if (sizes == null) return null;
        Camera.Size best = null;
        int bestArea = Integer.MAX_VALUE;
        for (Camera.Size s : sizes) {
            int a = s.width * s.height;
            if (s.width >= MIN_W && s.height >= MIN_H && a < bestArea) { best = s; bestArea = a; }
        }
        return best;
    }

    // ==================== 收尾 ====================

    private void emit(HandDetector.Gesture g) {
        Callback cb = callback;
        if (cb != null) cb.onGesture(g);
    }

    private void status(String s) {
        Callback cb = callback;
        if (cb != null) cb.onStatus(s);
    }

    @TargetApi(21)
    private void closeCamera2Only() {
        try { if (session != null) { session.close(); session = null; } } catch (Exception ignored) {}
        try { if (device != null) { device.close(); device = null; } } catch (Exception ignored) {}
        try { if (reader != null) { reader.close(); reader = null; } } catch (Exception ignored) {}
    }

    private void closeCamera() {
        if (Build.VERSION.SDK_INT >= 21) closeCamera2Only();
        if (legacy != null) {
            try {
                legacy.setPreviewCallback(null);
                legacy.stopPreview();
                legacy.release();
            } catch (Exception ignored) {}
            legacy = null;
        }
        if (dummy != null) { dummy.release(); dummy = null; }
    }
}
