package com.minivr.launcher;

import android.opengl.GLES20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

/** GLES2 小工具：buffer 分配、shader 编译（带错误信息）、运行时错误检查。 */
public final class Gl {

    private Gl() {}

    public static FloatBuffer fbuf(float[] a) {
        ByteBuffer bb = ByteBuffer.allocateDirect(a.length * 4);
        bb.order(ByteOrder.nativeOrder());
        FloatBuffer f = bb.asFloatBuffer();
        f.put(a);
        f.position(0);
        return f;
    }

    public static ShortBuffer sbuf(short[] a) {
        ByteBuffer bb = ByteBuffer.allocateDirect(a.length * 2);
        bb.order(ByteOrder.nativeOrder());
        ShortBuffer s = bb.asShortBuffer();
        s.put(a);
        s.position(0);
        return s;
    }

    public static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        int[] ok = new int[1];
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            throw new RuntimeException("link failed: " + GLES20.glGetProgramInfoLog(p));
        }
        return p;
    }

    public static int compile(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES20.glGetShaderInfoLog(s);
            GLES20.glDeleteShader(s);
            throw new RuntimeException("compile failed: " + log + "\n---\n" + src);
        }
        return s;
    }

    /** 调试期可在关键路径调用；发布版建议关掉以免每帧同步开销。 */
    public static void check(String tag) {
        int e = GLES20.glGetError();
        if (e != GLES20.GL_NO_ERROR) {
            throw new RuntimeException(tag + " glError=0x" + Integer.toHexString(e));
        }
    }
}
