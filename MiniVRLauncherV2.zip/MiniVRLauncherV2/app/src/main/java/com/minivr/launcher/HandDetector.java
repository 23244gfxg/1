package com.minivr.launcher;

/**
 * 纯 Java 手部检测，零 NDK / 零模型 / 零第三方库。
 *
 * 关键取舍：直接在 YUV 的色度通道(Cb/Cr)上做肤色分割，不转 RGB、不用 RenderScript、
 * 不依赖 ARCore 或 Google Play 服务 —— 因此 API 19 的老机器和国产 ROM 都能跑。
 *
 * 输出语义：
 *   张开手掌移动  → cx/cy 驱动准星
 *   张开后握拳    → pinch=true，等价于「点击」
 */
public class HandDetector {

    public static final int FW = 160;
    public static final int FH = 120;
    private static final int N = FW * FH;

    /** 统一的下采样帧：两条采集路径都产出这个结构，检测器只认它。 */
    public static final class Frame {
        public final byte[] y = new byte[N];
        public final byte[] cb = new byte[N];
        public final byte[] cr = new byte[N];

        public Frame() {}
    }

    public static final class Gesture {
        public boolean present;
        public float cx, cy;        // 掌心质心，0..1
        public float area;          // 手掌占画面比例
        public int fingers;         // 估计伸出的手指数（0..5）
        public boolean pinch;       // 握拳/捏合的下降沿
        public long stamp;

        public Gesture copy() {
            Gesture g = new Gesture();
            g.present = present; g.cx = cx; g.cy = cy; g.area = area;
            g.fingers = fingers; g.pinch = pinch; g.stamp = stamp;
            return g;
        }
    }

    private final boolean[] skin = new boolean[N];
    private final boolean[] tmp = new boolean[N];
    private final int[] label = new int[N];
    private final int[] stack = new int[N];

    // 状态机
    private boolean openSeen;
    private float openArea = 0.02f;
    private int closeFrames;
    private long lastPinch;

    private final Gesture out = new Gesture();

    public Gesture detect(Frame f) {
        // ---- 1. YCbCr 肤色判据（Kovac 经典区间 + 亮度/色差约束）----
        for (int i = 0; i < N; i++) {
            int yy = f.y[i] & 0xff;
            int b = f.cb[i] & 0xff;
            int r = f.cr[i] & 0xff;
            skin[i] = b >= 77 && b <= 127 && r >= 133 && r <= 173
                    && yy >= 45 && yy <= 245 && (r - b) > 18;
        }

        // ---- 2. 3x3 开运算：先腐蚀去噪点，再膨胀补回轮廓 ----
        erode(skin, tmp);
        dilate(tmp, skin);

        // ---- 3. 4 邻域连通域，取最大块 ----
        java.util.Arrays.fill(label, 0);
        int bestLabel = 0, bestSize = 0;
        int cur = 0;
        for (int i = 0; i < N; i++) {
            if (!skin[i] || label[i] != 0) continue;
            cur++;
            int sp = 0, count = 0;
            stack[sp++] = i;
            label[i] = cur;
            while (sp > 0) {
                int p = stack[--sp];
                count++;
                int x = p % FW, y = p / FW;
                if (x > 0 && skin[p - 1] && label[p - 1] == 0) { label[p - 1] = cur; stack[sp++] = p - 1; }
                if (x < FW - 1 && skin[p + 1] && label[p + 1] == 0) { label[p + 1] = cur; stack[sp++] = p + 1; }
                if (y > 0 && skin[p - FW] && label[p - FW] == 0) { label[p - FW] = cur; stack[sp++] = p - FW; }
                if (y < FH - 1 && skin[p + FW] && label[p + FW] == 0) { label[p + FW] = cur; stack[sp++] = p + FW; }
            }
            if (count > bestSize) { bestSize = count; bestLabel = cur; }
        }

        out.present = false;
        out.pinch = false;
        out.fingers = 0;
        out.area = 0;
        out.stamp = System.currentTimeMillis();

        if (bestSize < N * 0.006f) {
            // 手离开画面：重置，避免下次进来误判成握拳
            openSeen = false;
            closeFrames = 0;
            return out.copy();
        }

        // ---- 4. 最大块的质心、包围盒 ----
        double sx = 0, sy = 0;
        int minX = FW, maxX = 0, minY = FH, maxY = 0;
        for (int p = 0; p < N; p++) {
            if (label[p] != bestLabel) continue;
            int x = p % FW, y = p / FW;
            sx += x; sy += y;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        float mx = (float) (sx / bestSize), my = (float) (sy / bestSize);
        float radius = 0.5f * (float) Math.sqrt(
                (maxX - minX) * (double) (maxX - minX) + (maxY - minY) * (double) (maxY - minY));
        if (radius < 6f) return out.copy();

        // ---- 5. 径向采样估手指数：从质心向 24 个方向看肤色是否连续延伸到外圈 ----
        final int dirs = 24;
        boolean[] ray = new boolean[dirs];
        for (int d = 0; d < dirs; d++) {
            double a = 2 * Math.PI * d / dirs;
            int hit = 0;
            for (int s = 1; s <= 6; s++) {
                float rr = radius * (0.28f + 0.58f * s / 6f);
                int px = (int) (mx + Math.cos(a) * rr);
                int py = (int) (my + Math.sin(a) * rr);
                if (px < 0 || px >= FW || py < 0 || py >= FH) break;
                if (skin[py * FW + px]) hit++;
            }
            ray[d] = hit >= 4;
        }
        int segments = 0;
        for (int d = 0; d < dirs; d++) {
            if (ray[d] && !ray[(d - 1 + dirs) % dirs]) segments++;
        }
        int fingers = Math.min(5, segments);

        float area = bestSize / (float) N;
        out.present = true;
        out.cx = mx / FW;
        out.cy = my / FH;
        out.area = area;
        out.fingers = fingers;

        // ---- 6. 张开→握拳 的下降沿就是点击 ----
        if (fingers >= 4 && area > 0.012f) {
            openSeen = true;
            openArea = Math.max(openArea * 0.85f + area * 0.15f, area);
        }
        boolean closing = openSeen && (fingers <= 1 || area < openArea * 0.55f);
        closeFrames = closing ? closeFrames + 1 : 0;
        long now = out.stamp;
        if (closeFrames >= 2 && now - lastPinch > 700) {
            out.pinch = true;
            lastPinch = now;
            openSeen = false;
        }
        return out.copy();
    }

    private static void erode(boolean[] src, boolean[] dst) {
        for (int y = 0; y < FH; y++) {
            for (int x = 0; x < FW; x++) {
                int c = 0;
                for (int dy = -1; dy <= 1; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= FH) { c = -9; break; }
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx < 0 || xx >= FW || !src[yy * FW + xx]) { c = -9; break; }
                        c++;
                    }
                    if (c < 0) break;
                }
                dst[y * FW + x] = c == 9;
            }
        }
    }

    private static void dilate(boolean[] src, boolean[] dst) {
        for (int y = 0; y < FH; y++) {
            for (int x = 0; x < FW; x++) {
                boolean any = false;
                for (int dy = -1; dy <= 1 && !any; dy++) {
                    int yy = y + dy;
                    if (yy < 0 || yy >= FH) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int xx = x + dx;
                        if (xx >= 0 && xx < FW && src[yy * FW + xx]) { any = true; break; }
                    }
                }
                dst[y * FW + x] = any;
            }
        }
    }
}
