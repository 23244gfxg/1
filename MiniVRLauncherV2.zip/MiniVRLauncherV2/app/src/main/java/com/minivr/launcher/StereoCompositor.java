package com.minivr.launcher;

import android.opengl.GLES20;

import java.nio.FloatBuffer;

/**
 * 每只眼渲染到独立 FBO，最后用一次全屏 pass 做透镜预畸变再贴到屏幕左右半边。
 * 这就是 Cardboard 那套 compositor 的最小实现（不含 timewarp）。
 */
public class StereoCompositor {

    private static final String VS =
            "attribute vec2 aPos;" +
            "varying vec2 vUV;" +
            "void main(){ vUV=(aPos+1.0)*0.5; gl_Position=vec4(aPos,0.0,1.0); }";

    private static final String FS =
            "precision mediump float;" +
            "varying vec2 vUV;" +
            "uniform sampler2D uLeft;" +
            "uniform sampler2D uRight;" +
            "uniform vec2 uK;" +        // k1, k2 径向畸变系数
            "uniform float uScale;" +   // 缩放补偿，避免边缘被拉出黑边过多
            "void main(){" +
            "  float u = vUV.x < 0.5 ? vUV.x*2.0 : (vUV.x-0.5)*2.0;" +
            "  vec2 c = vec2(u, vUV.y) - 0.5;" +
            "  float r2 = dot(c,c);" +
            "  vec2 d = c * (1.0 + uK.x*r2 + uK.y*r2*r2) / uScale;" +
            "  vec2 src = 0.5 + d;" +
            "  vec4 cL = texture2D(uLeft,src);" +
            "  vec4 cR = texture2D(uRight,src);" +
            "  vec4 col = vUV.x<0.5 ? cL : cR;" +
            "  float inside = step(0.0,src.x)*step(src.x,1.0)*step(0.0,src.y)*step(src.y,1.0);" +
            "  gl_FragColor = col*inside;" +
            "}";

    // 温和的枕形预畸变；若你的盒子透镜畸变大可调大，设为 0,0 即关闭（纯左右分屏）
    private static final float K1 = 0.15f;
    private static final float K2 = 0.05f;

    private int program = -1, aPos, uLeft, uRight, uK, uScale;
    private FloatBuffer quad;
    private int w = 0, h = 0, ew = 0, eh = 0;

    private final int[] fbo = {0, 0};
    private final int[] color = {0, 0};
    private final int[] depth = {0, 0};

    public int width() { return w; }
    public int height() { return h; }

    public void init(int width, int height) {
        release();
        w = width;
        h = height;
        ew = Math.max(1, width / 2);
        eh = Math.max(1, height);

        program = Gl.program(VS, FS);
        aPos = GLES20.glGetAttribLocation(program, "aPos");
        uLeft = GLES20.glGetUniformLocation(program, "uLeft");
        uRight = GLES20.glGetUniformLocation(program, "uRight");
        uK = GLES20.glGetUniformLocation(program, "uK");
        uScale = GLES20.glGetUniformLocation(program, "uScale");
        quad = Gl.fbuf(new float[]{-1, -1, 1, -1, 1, 1, -1, 1});

        GLES20.glGenFramebuffers(2, fbo, 0);
        GLES20.glGenTextures(2, color, 0);
        GLES20.glGenRenderbuffers(2, depth, 0);

        for (int i = 0; i < 2; i++) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, color[i]);
            GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, ew, eh, 0,
                    GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null);

            GLES20.glBindRenderbuffer(GLES20.GL_RENDERBUFFER, depth[i]);
            GLES20.glRenderbufferStorage(GLES20.GL_RENDERBUFFER,
                    GLES20.GL_DEPTH_COMPONENT16, ew, eh);

            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[i]);
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0,
                    GLES20.GL_TEXTURE_2D, color[i], 0);
            GLES20.glFramebufferRenderbuffer(GLES20.GL_FRAMEBUFFER, GLES20.GL_DEPTH_ATTACHMENT,
                    GLES20.GL_RENDERBUFFER, depth[i]);

            int status = GLES20.glCheckFramebufferStatus(GLES20.GL_FRAMEBUFFER);
            if (status != GLES20.GL_FRAMEBUFFER_COMPLETE) {
                throw new RuntimeException("FBO incomplete: 0x" + Integer.toHexString(status));
            }
        }
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glBindRenderbuffer(GLES20.GL_RENDERBUFFER, 0);
    }

    public void bindEye(boolean left) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[left ? 0 : 1]);
        GLES20.glViewport(0, 0, ew, eh);
    }

    public void composite() {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0);
        GLES20.glViewport(0, 0, w, h);
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_BLEND);
        GLES20.glClearColor(0f, 0f, 0f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);

        GLES20.glUseProgram(program);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, color[0]);
        GLES20.glUniform1i(uLeft, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, color[1]);
        GLES20.glUniform1i(uRight, 1);

        GLES20.glUniform2f(uK, K1, K2);
        // 在 r²≈0.25 处归一化，让画面主体保持原尺寸
        float scale = 1f + K1 * 0.25f + K2 * 0.0625f;
        GLES20.glUniform1f(uScale, scale);

        quad.position(0);
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad);
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4);
        GLES20.glDisableVertexAttribArray(aPos);

        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
    }

    public void release() {
        if (fbo[0] != 0) { GLES20.glDeleteFramebuffers(2, fbo, 0); fbo[0] = fbo[1] = 0; }
        if (color[0] != 0) { GLES20.glDeleteTextures(2, color, 0); color[0] = color[1] = 0; }
        if (depth[0] != 0) { GLES20.glDeleteRenderbuffers(2, depth, 0); depth[0] = depth[1] = 0; }
        if (program != -1) { GLES20.glDeleteProgram(program); program = -1; }
    }
}
