package com.minivr.launcher;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.opengl.GLES20;
import android.opengl.GLUtils;

import java.util.Random;

/** 程序化生成的 1024x512 等距柱状星空，零图片资源。 */
public class Skybox {

    private int texture;
    private SphereMesh mesh;

    public void init() {
        texture = uploadStarfield();
        mesh = new SphereMesh(false);
        mesh.init();
    }

    public void draw(float[] vpNoTrans) {
        mesh.draw(vpNoTrans, texture, new float[]{1f, 1f, 0f, 0f});
    }

    public void release() {
        if (texture != 0) GLES20.glDeleteTextures(1, new int[]{texture}, 0);
        if (mesh != null) mesh.release();
    }

    private static int uploadStarfield() {
        int w = 1024, h = 512;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);

        Paint bg = new Paint();
        bg.setShader(new LinearGradient(0, 0, 0, h,
                0xFF03050E, 0xFF101A3A, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, bg);

        c.save();
        c.rotate(-16f, w / 2f, h / 2f);
        Paint band = new Paint();
        band.setShader(new LinearGradient(0, h * 0.28f, 0, h * 0.72f,
                new int[]{0x00000000, 0x334A78C8, 0x00000000},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(-w, h * 0.28f, w * 2f, h * 0.72f, band);
        c.restore();

        Random r = new Random(20261123L);
        Paint star = new Paint(Paint.ANTI_ALIAS_FLAG);
        star.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 1100; i++) {
            float x = r.nextFloat() * w, y = r.nextFloat() * h;
            int a = 60 + r.nextInt(195);
            star.setColor(Color.argb(a, 220 + r.nextInt(35), 225 + r.nextInt(30), 255));
            c.drawCircle(x, y, 0.4f + r.nextFloat() * 1.3f, star);
        }
        for (int i = 0; i < 18; i++) {
            float x = r.nextFloat() * w, y = r.nextFloat() * h;
            star.setColor(Color.argb(180, 255, 255, 255));
            c.drawCircle(x, y, 1.8f, star);
            star.setStrokeWidth(1f);
            c.drawLine(x - 7, y, x + 7, y, star);
            c.drawLine(x, y - 7, x, y + 7, star);
        }

        int[] tex = new int[1];
        GLES20.glGenTextures(1, tex, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0]);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_REPEAT);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0);
        bmp.recycle();
        return tex[0];
    }
}
