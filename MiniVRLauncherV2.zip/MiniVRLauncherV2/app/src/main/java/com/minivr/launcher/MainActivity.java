package com.minivr.launcher;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    /** 开放式支架 / 拆掉盒子背板时用后置；若前摄位置有开孔可改 true。 */
    private static final boolean PREFER_FRONT_CAMERA = false;
    private static final int REQ_PERMS = 1001;

    private StereoView stereoView;
    private HandTracker tracker;
    private LauncherRenderer renderer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 主题已是 NoTitleBar.Fullscreen，不要再 requestWindowFeature，部分 ROM 会抛异常
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        renderer = new LauncherRenderer(this);
        tracker = new HandTracker();
        stereoView = new StereoView(this);
        renderer.attach(stereoView, tracker);
        stereoView.setCallback(renderer);
        setContentView(stereoView);

        requestNeededPermissions();
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT < 23) return;   // 安装时已授予
        List<String> want = new ArrayList<String>();
        want.add(Manifest.permission.CAMERA);
        if (Build.VERSION.SDK_INT >= 33) {
            want.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else {
            want.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        List<String> missing = new ArrayList<String>();
        for (String p : want) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) missing.add(p);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        // 摄像头被拒也不影响凝视模式，HandTracker 内部会捕获 SecurityException
    }

    @Override
    protected void onResume() {
        super.onResume();
        stereoView.onResume();
        stereoView.startSensors();
        tracker.start(this, PREFER_FRONT_CAMERA, renderer);
    }

    @Override
    protected void onPause() {
        tracker.stop();
        stereoView.stopSensors();
        stereoView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        // 只释放 MediaPlayer / Surface；GL 纹理与 program 由 EGL 上下文销毁时统一回收
        renderer.releasePlayerOnly();
        super.onDestroy();
    }
}
