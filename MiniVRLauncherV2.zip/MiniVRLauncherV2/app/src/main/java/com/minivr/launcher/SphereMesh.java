package com.minivr.launcher;

import android.opengl.GLES20;
import android.opengl.GLES11Ext;

import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

/**
 * 等距柱状球面网格。天空盒（sampler2D）与视频球（samplerExternalOES）共用同一套几何，
 * 只换 fragment shader。球面从内壁观看，不启用 CULL_FACE。
 *
 * UV u=0.5 正对用户开机朝向(-Z)，所以全景视频的正前方能对准视线中心。
 */
public class SphereMesh {

    private static final int STACKS = 28;
    private static final int SLICES = 56;
    private static final float RADIUS = 30f;

    private static final String VS =
            "uniform mat4 uMVP;" +
            "attribute vec3 aPos;" +
            "attribute vec2 aUV;" +
            "varying vec2 vUV;" +
            "void main(){ vUV=aUV; gl_Position=uMVP*vec4(aPos,1.0); }";

    private static final String FS_2D =
            "precision mediump float;" +
            "varying vec2 vUV;" +
            "uniform sampler2D uTex;" +
            "uniform vec4 uUvT;" +      // scaleX, scaleY, offX, offY
            "void main(){ gl_FragColor=texture2D(uTex, vUV*uUvT.xy+uUvT.zw); }";

    private static final String FS_OES =
            "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float;" +
            "varying vec2 vUV;" +
            "uniform samplerExternalOES uTex;" +
            "uniform vec4 uUvT;" +
            "void main(){ gl_FragColor=texture2D(uTex, vUV*uUvT.xy+uUvT.zw); }";

    private final boolean oes;
    private final float sweep;
    private int program, aPos, aUV, uMVP, uTex, uUvT;
    private FloatBuffer posBuf, uvBuf;
    private ShortBuffer idxBuf;
    private int indexCount;

    /** @param oes true = 视频球(GL_TEXTURE_EXTERNAL_OES)，false = 普通 2D 纹理 */
    public SphereMesh(boolean oes) {
        this(oes, (float) (2 * Math.PI));
    }

    /**
     * @param oes   true = 视频球，false = 普通 2D 纹理
     * @param sweep 球面水平张角（弧度）：2π = 360 全景，π = 前 180°
     */
    public SphereMesh(boolean oes, float sweep) {
        this.oes = oes;
        this.sweep = sweep;
    }

    /** 必须在 GL 线程调用。 */
    public void init() {
        program = Gl.program(VS, oes ? FS_OES : FS_2D);
        aPos = GLES20.glGetAttribLocation(program, "aPos");
        aUV = GLES20.glGetAttribLocation(program, "aUV");
        uMVP = GLES20.glGetUniformLocation(program, "uMVP");
        uTex = GLES20.glGetUniformLocation(program, "uTex");
        uUvT = GLES20.glGetUniformLocation(program, "uUvT");
        build();
    }

    /**
     * @param vp       投影*视图矩阵（天空盒传 vpNoTrans，视频球传完整 vp）
     * @param texId    纹理句柄
     * @param uvT      {scaleX, scaleY, offX, offY}，用于 180/360、SBS/TB 分屏
     */
    public void draw(float[] vp, int texId, float[] uvT) {
        GLES20.glUseProgram(program);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, vp, 0);
        GLES20.glUniform4f(uUvT, uvT[0], uvT[1], uvT[2], uvT[3]);

        int target = oes ? GLES11Ext.GL_TEXTURE_EXTERNAL_OES : GLES20.GL_TEXTURE_2D;
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(target, texId);
        GLES20.glUniform1i(uTex, 0);

        posBuf.position(0);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, posBuf);
        GLES20.glEnableVertexAttribArray(aPos);
        uvBuf.position(0);
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 0, uvBuf);
        GLES20.glEnableVertexAttribArray(aUV);
        idxBuf.position(0);

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount,
                GLES20.GL_UNSIGNED_SHORT, idxBuf);

        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aUV);
    }

    private void build() {
        int vc = (STACKS + 1) * (SLICES + 1);
        float[] pos = new float[vc * 3];
        float[] uv = new float[vc * 2];
        short[] idx = new short[STACKS * SLICES * 6];

        int vi = 0, ui = 0;
        for (int i = 0; i <= STACKS; i++) {
            float phi = (float) (Math.PI * i / STACKS);
            float sp = (float) Math.sin(phi), cp = (float) Math.cos(phi);
            for (int j = 0; j <= SLICES; j++) {
                float u = j / (float) SLICES;
                // u=0.5 → theta=-π/2 → -Z（正前方）
                float theta = (float) (-Math.PI / 2) + (u - 0.5f) * sweep;
                pos[vi++] = -sp * (float) Math.cos(theta) * RADIUS;
                pos[vi++] = cp * RADIUS;
                pos[vi++] = sp * (float) Math.sin(theta) * RADIUS;
                uv[ui++] = u;
                uv[ui++] = i / (float) STACKS;
            }
        }

        int ii = 0;
        for (int i = 0; i < STACKS; i++) {
            for (int j = 0; j < SLICES; j++) {
                short a = (short) (i * (SLICES + 1) + j);
                short b = (short) (a + SLICES + 1);
                idx[ii++] = a; idx[ii++] = b; idx[ii++] = (short) (a + 1);
                idx[ii++] = (short) (a + 1); idx[ii++] = b; idx[ii++] = (short) (b + 1);
            }
        }
        indexCount = idx.length;
        posBuf = Gl.fbuf(pos);
        uvBuf = Gl.fbuf(uv);
        idxBuf = Gl.sbuf(idx);
    }

    public void release() {
        if (program != 0) {
            GLES20.glDeleteProgram(program);
            program = 0;
        }
    }
}
