package com.minivr.launcher;

/**
 * 统一输入层：把「陀螺仪凝视」和「摄像头手势」压成同一套
 * (平面坐标 + 命中索引 + 触发事件)，渲染器不用关心当前是哪种输入。
 *
 * GAZE：视线打到 z=PANEL_Z 平面的交点，停留 1.2s 触发
 * HAND：掌心质心映射到同一平面，握拳(pinch) 立即触发；检测到手时自动切过来
 */
public class GazeInput {

    public static final float PANEL_Z = -2f;
    public static final float HIT_HALF = 0.46f;
    public static final float HIT_HYST = 0.50f;

    private static final float LP = 0.82f;          // 一阶低通旧值权重
    private static final int TRIGGER_FRAMES = 72;   // 凝视 1.2s @60fps
    private static final int COOLDOWN_FRAMES = 90;  // 触发后 1.5s 冷却
    private static final long HAND_TTL = 700;       // 手势结果有效期(ms)
    private static final float HAND_RANGE_X = 4.6f;
    private static final float HAND_RANGE_Y = 3.0f;

    private final float[] fwd = {0, 0, -1};
    private volatile HandDetector.Gesture gesture;

    private float[] xs = new float[0], ys = new float[0];
    private float filtX, filtY;
    private boolean filtInit;
    private int hovered = -1, hoverFrames, cooldown;
    private boolean pendingTrigger;
    private boolean usingHand;
    private boolean mirrorHand = true;
    private float progress;
    private long lastPinchStamp = -1;
    private boolean lastUsingHand;

    public void setHead(float[] fwd3) {
        fwd[0] = fwd3[0]; fwd[1] = fwd3[1]; fwd[2] = fwd3[2];
    }

    /** 摄像头线程写入；GL 线程读取。Gesture 是不可变快照，volatile 发布即可。 */
    public void setGesture(HandDetector.Gesture g) {
        gesture = g;
    }

    /** 切屏时调用；顺手清掉 hover 状态，避免旧屏的进度带过来。 */
    public void setTargets(float[] xArr, float[] yArr) {
        xs = xArr; ys = yArr;
        hovered = -1;
        hoverFrames = 0;
        progress = 0;
    }

    public void setMirrorHand(boolean m) { mirrorHand = m; }
    public boolean isMirrorHand() { return mirrorHand; }

    public void setGestureEnabled(boolean enabled) {
        if (!enabled) gesture = null;
    }

    public float x() { return filtX; }
    public float y() { return filtY; }
    public int hovered() { return hovered; }
    public float progress() { return progress; }
    public boolean usingHand() { return usingHand; }

    /** 输入模式刚发生变化时返回 true，用于弹一次提示。 */
    public boolean modeChanged() {
        boolean c = (usingHand != lastUsingHand);
        lastUsingHand = usingHand;
        return c;
    }

    public boolean consumeTrigger() {
        if (!pendingTrigger) return false;
        pendingTrigger = false;
        return true;
    }

    public void clearTrigger() {
        pendingTrigger = false;
        cooldown = COOLDOWN_FRAMES;
    }

    /** 每帧在 GL 线程调用一次（画两眼之前）。 */
    public void update() {
        long now = System.currentTimeMillis();
        HandDetector.Gesture g = gesture;
        boolean hand = g != null && g.present && (now - g.stamp) < HAND_TTL;
        usingHand = hand;

        float tx, ty;
        if (hand) {
            float u = mirrorHand ? (1f - g.cx) : g.cx;
            tx = (u - 0.5f) * HAND_RANGE_X;
            ty = (0.5f - g.cy) * HAND_RANGE_Y;
        } else {
            float fz = fwd[2];
            if (fz > -0.01f) {
                tx = filtX; ty = filtY;                 // 没朝前看，保持上一帧
            } else {
                float d = PANEL_Z / fz;
                tx = fwd[0] * d;
                ty = fwd[1] * d;
            }
        }

        // 一阶低通：只滤波 2D 交点，不滤波四元数（后者会引入万向锁/相位问题）
        if (!filtInit) {
            filtX = tx; filtY = ty; filtInit = true;
        } else {
            filtX = LP * filtX + (1f - LP) * tx;
            filtY = LP * filtY + (1f - LP) * ty;
        }

        if (cooldown > 0) {
            cooldown--;
            hovered = -1;
            hoverFrames = 0;
            progress = 0;
            return;
        }

        int hit = -1;
        for (int i = 0; i < xs.length; i++) {
            float half = (i == hovered) ? HIT_HYST : HIT_HALF;
            if (Math.abs(filtX - xs[i]) < half && Math.abs(filtY - ys[i]) < half) {
                hit = i;
                break;
            }
        }
        if (hit == hovered) hoverFrames++;
        else { hovered = hit; hoverFrames = 0; }

        if (hand) {
            // 握拳下降沿 = 点击；手势模式下不再需要凝视计时
            if (hovered >= 0 && g.pinch && g.stamp != lastPinchStamp) {
                lastPinchStamp = g.stamp;
                pendingTrigger = true;
                cooldown = COOLDOWN_FRAMES;
            }
            progress = (hovered >= 0) ? 0.8f : 0f;
        } else {
            if (hovered >= 0 && hoverFrames >= TRIGGER_FRAMES) {
                pendingTrigger = true;
                cooldown = COOLDOWN_FRAMES;
                hoverFrames = 0;
            }
            progress = (hovered >= 0) ? hoverFrames / (float) TRIGGER_FRAMES : 0f;
        }
    }
}
