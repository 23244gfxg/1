package com.minivr.launcher;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * 替代 GvrView 的纯 Android 双目渲染框架。
 *
 * 只用三样系统能力：GLSurfaceView(GLES2) + SensorManager 旋转矢量 + Matrix 数学。
 * 不依赖 Google VR SDK / GMS / ARCore / NDK，因此任何 ROM 都能编译。
 *
 * 坐标系：开机时的朝向被校准为零位（前方 = -Z，上 = +Y，右 = +X）。
 * 用「相对四元数 q0^-1 ⊗ q」而不是世界 ENU 轴，彻底绕开
 * remapCoordinateSystem 在不同横屏/竖屏机型上的差异。
 */
public class StereoView extends GLSurfaceView
        implements GLSurfaceView.Renderer, SensorEventListener {

    public static final class EyeFrame {
        public final float[] vp = new float[16];
        public final float[] vpNoTrans = new float[16];
        public final boolean left;
        public int width, height;

        EyeFrame(boolean left) {
            this.left = left;
        }
    }

    public interface FrameCallback {
        void onGlReady();
        void onResize(int width, int height);
        void onFrame();
        void onDrawEye(EyeFrame eye);
    }

    private static final float IPD = 0.064f;
    private static final float CONVERGENCE = 2.0f;   // 与面板平面 z=-2 一致
    private static final float NEAR = 0.1f;
    private static final float FAR = 120f;

    private final SensorManager sensors;
    private final Sensor rotSensor;
    private final StereoCompositor compositor = new StereoCompositor();
    private FrameCallback callback;

    private volatile float[] qCur;      // 当前姿态四元数 (x,y,z,w)
    private volatile float[] qZero;     // 零位校准
    private volatile float fovDeg = 95f;

    private final float[] qRel = {0, 0, 0, 1};
    private final float[] relRot = new float[16];
    private final float[] eyeRot = new float[16];
    private final float[] view = new float[16];
    private final float[] proj = new float[16];
    private final float[] headFwd = {0, 0, -1};

    private final EyeFrame leftEye = new EyeFrame(true);
    private final EyeFrame rightEye = new EyeFrame(false);

    public StereoView(Context ctx) {
        super(ctx);
        setEGLContextClientVersion(2);
        // 默认帧缓冲只用于最终合成（不做深度测试），真正的深度在 FBO 的
        // DEPTH_COMPONENT16 renderbuffer 里。这里不要 stencil，给老设备留更多可选 config。
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        setRenderer(this);
        setRenderMode(RENDERMODE_CONTINUOUSLY);

        sensors = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        // GAME_ROTATION_VECTOR 不依赖磁力计，国产 ROM / 强磁环境更稳
        Sensor s = null;
        if (sensors != null) {
            s = sensors.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
            if (s == null) s = sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        }
        rotSensor = s;
    }

    public void setCallback(FrameCallback cb) {
        this.callback = cb;
    }

    public void startSensors() {
        if (sensors != null && rotSensor != null) {
            sensors.registerListener(this, rotSensor, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    public void stopSensors() {
        if (sensors != null) sensors.unregisterListener(this);
    }

    /** 把当前朝向设为正前方（低头/歪了时调用）。 */
    public void recenter() {
        float[] q = qCur;
        if (q != null) qZero = q.clone();
    }

    public void setFov(float degrees) {
        fovDeg = degrees;
    }

    public void getHeadForward(float[] out3) {
        out3[0] = headFwd[0];
        out3[1] = headFwd[1];
        out3[2] = headFwd[2];
    }

    public boolean hasAttitude() {
        return qCur != null;
    }

    // ================= Sensor =================

    @Override
    public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1], z = e.values[2];
        float w;
        if (e.values.length >= 4) {
            w = e.values[3];
        } else {
            w = (float) Math.sqrt(Math.max(0f, 1f - x * x - y * y - z * z));
        }
        float n = (float) Math.sqrt(x * x + y * y + z * z + w * w);
        if (n < 1e-6f) return;
        float[] q = {x / n, y / n, z / n, w / n};
        qCur = q;
        if (qZero == null) qZero = q.clone();       // 首帧自动校准零位
    }

    @Override
    public void onAccuracyChanged(Sensor s, int accuracy) {
    }

    // ================= Renderer =================

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glEnable(GLES20.GL_BLEND);
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA);
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1);
        // 故意不开 CULL_FACE：球面从内壁看，绕序不重要
        if (callback != null) callback.onGlReady();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        compositor.init(width, height);
        if (callback != null) callback.onResize(width, height);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        updateAttitude();
        if (callback != null) callback.onFrame();

        int w = compositor.width(), h = compositor.height();
        if (w <= 0 || h <= 0) return;
        buildEye(leftEye, w / 2, h);
        buildEye(rightEye, w / 2, h);

        compositor.bindEye(true);
        if (callback != null) callback.onDrawEye(leftEye);

        compositor.bindEye(false);
        if (callback != null) callback.onDrawEye(rightEye);

        compositor.composite();
    }

    private void buildEye(EyeFrame eye, int ew, int eh) {
        eye.width = ew;
        eye.height = eh;
        float near = NEAR, far = FAR;
        float top = (float) (near * Math.tan(Math.toRadians(fovDeg) * 0.5));
        float aspect = (float) ew / (float) eh;
        float right0 = top * aspect;

        // Off-axis 视锥：让 z=-CONVERGENCE 处的正前方点在两只眼画面里都居中，
        // 融像才不累。平行视锥会逼眼睛外散，别用。
        float e = IPD * 0.5f;
        float shift = e * near / CONVERGENCE;
        float s = eye.left ? shift : -shift;
        Matrix.frustumM(proj, 0, -right0 + s, right0 + s, -top, top, near, far);

        // view[12] = -cameraX：左眼相机在 -e，故 +e
        System.arraycopy(eyeRot, 0, view, 0, 16);
        view[12] = eye.left ? e : -e;
        view[13] = 0f;
        view[14] = 0f;

        Matrix.multiplyMM(eye.vp, 0, proj, 0, view, 0);
        Matrix.multiplyMM(eye.vpNoTrans, 0, proj, 0, eyeRot, 0);
    }

    /** 相对四元数 → 旋转矩阵 → forward 向量 + view 旋转(R^T)。 */
    private void updateAttitude() {
        float[] q = qCur;
        float[] z = qZero;
        if (q != null && z != null) {
            // qRel = conj(q0) ⊗ q
            float[] inv = {-z[0], -z[1], -z[2], z[3]};
            quatMul(qRel, inv, q);
        }
        quatToMatrix(relRot, qRel);

        headFwd[0] = -relRot[8];
        headFwd[1] = -relRot[9];
        headFwd[2] = -relRot[10];

        // R^T（列主序：交换 [1]<->[4]、[2]<->[8]、[6]<->[9]）
        eyeRot[0] = relRot[0];  eyeRot[1] = relRot[4];  eyeRot[2] = relRot[8];   eyeRot[3] = 0;
        eyeRot[4] = relRot[1];  eyeRot[5] = relRot[5];  eyeRot[6] = relRot[9];   eyeRot[7] = 0;
        eyeRot[8] = relRot[2];  eyeRot[9] = relRot[6];  eyeRot[10] = relRot[10]; eyeRot[11] = 0;
        eyeRot[12] = 0; eyeRot[13] = 0; eyeRot[14] = 0; eyeRot[15] = 1;
    }

    private static void quatMul(float[] out, float[] a, float[] b) {
        float ax = a[0], ay = a[1], az = a[2], aw = a[3];
        float bx = b[0], by = b[1], bz = b[2], bw = b[3];
        out[0] = aw * bx + ax * bw + ay * bz - az * by;
        out[1] = aw * by - ax * bz + ay * bw + az * bx;
        out[2] = aw * bz + ax * by - ay * bx + az * bw;
        out[3] = aw * bw - ax * bx - ay * by - az * bz;
    }

    /** 单位四元数 → OpenGL 列主序 4x4 旋转矩阵。 */
    private static void quatToMatrix(float[] m, float[] q) {
        float x = q[0], y = q[1], z = q[2], w = q[3];
        float xx = x * x, yy = y * y, zz = z * z;
        float xy = x * y, xz = x * z, yz = y * z;
        float wx = w * x, wy = w * y, wz = w * z;
        m[0] = 1 - 2 * (yy + zz); m[1] = 2 * (xy + wz);     m[2] = 2 * (xz - wy);     m[3] = 0;
        m[4] = 2 * (xy - wz);     m[5] = 1 - 2 * (xx + zz); m[6] = 2 * (yz + wx);     m[7] = 0;
        m[8] = 2 * (xz + wy);     m[9] = 2 * (yz - wx);     m[10] = 1 - 2 * (xx + yy); m[11] = 0;
        m[12] = 0; m[13] = 0; m[14] = 0; m[15] = 1;
    }

    public void release() {
        compositor.release();
    }
}
