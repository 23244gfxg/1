package com.minivr.launcher;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.net.Uri;
import android.opengl.GLES20;
import android.opengl.GLES11Ext;
import android.view.Surface;

import java.io.IOException;

/**
 * 内置 360/180 球面视频播放器：MediaPlayer → SurfaceTexture → GL_TEXTURE_EXTERNAL_OES → 球面网格。
 * 全程留在 VR 场景里，不跳任何 2D Activity。
 */
public class VideoPlayer {

    public enum Format {
        MONO_360, SBS_360, TB_360, MONO_180, SBS_180
    }

    private int texId;
    private SurfaceTexture surfaceTexture;
    private Surface surface;
    private MediaPlayer player;
    private volatile boolean framePending;
    private volatile boolean ready;
    private volatile String error;

    private Format format = Format.MONO_360;
    private boolean mirrorU;
    private boolean playing;

    /** 必须在 GL 线程调用一次。 */
    public void initGL() {
        int[] t = new int[1];
        GLES20.glGenTextures(1, t, 0);
        texId = t[0];
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,
                GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);

        surfaceTexture = new SurfaceTexture(texId);
        // listener 回调可能在主线程；用 volatile 标志，真正 updateTexImage 仍在 GL 线程做
        surfaceTexture.setOnFrameAvailableListener(new SurfaceTexture.OnFrameAvailableListener() {
            @Override public void onFrameAvailable(SurfaceTexture st) { framePending = true; }
        });
        surface = new Surface(surfaceTexture);
    }

    public void play(Context ctx, Uri uri) {
        releasePlayer();
        ready = false;
        error = null;
        MediaPlayer mp = new MediaPlayer();
        player = mp;
        try {
            mp.setSurface(surface);
            mp.setDataSource(ctx, uri);
            mp.setLooping(true);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer m) {
                    ready = true;
                    m.start();
                    playing = true;
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer m, int what, int extra) {
                    error = "what=" + what + " extra=" + extra;
                    return true;
                }
            });
            mp.prepareAsync();
        } catch (IOException e) {
            error = e.getMessage();
        } catch (RuntimeException e) {
            error = e.getMessage();
        }
    }

    /** 每帧只调一次（在画两眼之前），必须在 GL 线程。 */
    public void updateTexImage() {
        if (surfaceTexture != null && framePending) {
            surfaceTexture.updateTexImage();
            framePending = false;
        }
    }

    public void togglePause() {
        MediaPlayer mp = player;
        if (mp == null || !ready) return;
        if (playing) { mp.pause(); playing = false; }
        else { mp.start(); playing = true; }
    }

    public void setFormat(Format f) { format = f; }
    public Format getFormat() { return format; }
    public void cycleFormat() {
        Format[] all = Format.values();
        format = all[(format.ordinal() + 1) % all.length];
    }
    public void setMirrorU(boolean m) { mirrorU = m; }
    public boolean isMirrorU() { return mirrorU; }

    public boolean is180() { return format == Format.MONO_180 || format == Format.SBS_180; }
    public boolean isReady() { return ready; }
    public boolean isPlaying() { return playing; }
    public String getError() { return error; }
    public int texId() { return texId; }

    /** {scaleX, scaleY, offX, offY}：把左右眼分别映射到 SBS/TB 的对应半区。 */
    public float[] uvFor(boolean leftEye) {
        float sx = 1f, sy = 1f, ox = 0f, oy = 0f;
        switch (format) {
            case SBS_360:
            case SBS_180:
                sx = 0.5f;
                ox = leftEye ? 0f : 0.5f;
                break;
            case TB_360:
                sy = 0.5f;
                // t=0 是图像顶部（Bitmap/SurfaceTexture 约定），左眼取上半
                oy = leftEye ? 0f : 0.5f;
                break;
            case MONO_360:
            case MONO_180:
            default:
                break;
        }
        if (mirrorU) {
            // u → 1-u ：uv' = -sx*u + (sx+ox)
            ox = sx + ox;
            sx = -sx;
        }
        return new float[]{sx, sy, ox, oy};
    }

    private void releasePlayer() {
        MediaPlayer mp = player;
        player = null;
        if (mp != null) {
            try { mp.reset(); } catch (Exception ignored) {}
            try { mp.release(); } catch (Exception ignored) {}
        }
        ready = false;
        playing = false;
    }

    /** 非 GL 线程可安全调用（Activity.onDestroy）：只释放播放器与 Surface。 */
    public void releasePlayerOnly() {
        releasePlayer();
        if (surface != null) { surface.release(); surface = null; }
        if (surfaceTexture != null) { surfaceTexture.release(); surfaceTexture = null; }
    }

    /** GL 线程调用：额外删除 OES 纹理。 */
    public void release() {
        releasePlayerOnly();
        if (texId != 0) {
            GLES20.glDeleteTextures(1, new int[]{texId}, 0);
            texId = 0;
        }
    }
}
