package com.minivr.launcher;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.widget.Toast;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 迷你启动器渲染器（v2）。
 *
 * 四个场景共用一套面板 + 准星 + 统一输入：
 *   LAUNCHER（6 宫格）→ LIBRARY（本地视频网格）→ VIDEO（内置球面播放）
 *   LAUNCHER → SETTINGS（回正 / 镜像 / 格式 / 手势开关）
 *
 * VIDEO 全程留在 VR 场景里：MediaPlayer 喂 SurfaceTexture，贴到球面网格，
 * 左右眼分别取 SBS/TB 的对应半区，不再跳任何 2D 播放器。
 */
public class LauncherRenderer implements StereoView.FrameCallback, HandTracker.Callback {

    private static final int SCREEN_LAUNCHER = 0;
    private static final int SCREEN_LIBRARY = 1;
    private static final int SCREEN_SETTINGS = 2;
    private static final int SCREEN_VIDEO = 3;

    private static final float QUAD_HALF = 0.42f;
    private static final float CURSOR_Z = -1.2f;

    private static final String VS =
            "uniform mat4 uMVP;" +
            "attribute vec3 aPos;" +
            "attribute vec2 aUV;" +
            "varying vec2 vUV;" +
            "void main(){ vUV=aUV; gl_Position=uMVP*vec4(aPos,1.0); }";
    private static final String FS =
            "precision mediump float;" +
            "varying vec2 vUV;" +
            "uniform sampler2D uTex;" +
            "uniform vec4 uTint;" +
            "void main(){ gl_FragColor=texture2D(uTex,vUV)*uTint; }";

    private static class Item {
        int tex;
        float x, y;
        Runnable action;
        Item(int t, float x, float y, Runnable a) { tex = t; this.x = x; this.y = y; action = a; }
    }

    private static class VideoEntry {
        String name;
        Uri uri;
    }

    private final Context ctx;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private StereoView view;
    private HandTracker tracker;

    private final GazeInput gaze = new GazeInput();
    private final float[] fwd = new float[3];

    private int panelProgram, aPos, aUV, uMVP, uTex, uTint;
    private FloatBuffer quadPos, quadUV;
    private int cursorTex;
    private final Map<String, Integer> texCache = new HashMap<String, Integer>();

    private Skybox skybox;
    private SphereMesh sphere360, sphere180;
    private final VideoPlayer video = new VideoPlayer();

    private final float[] model = new float[16];
    private final float[] tmp = new float[16];

    private final List<Item> items = new ArrayList<Item>();
    private final List<VideoEntry> videos = new ArrayList<VideoEntry>();
    private float[] targetX = new float[0], targetY = new float[0];
    private int screen = SCREEN_LAUNCHER;
    private boolean gestureEnabled = true;

    public LauncherRenderer(Context c) { ctx = c.getApplicationContext(); }

    public void attach(StereoView v, HandTracker t) {
        view = v;
        tracker = t;
    }

    // ==================== FrameCallback ====================

    @Override
    public void onGlReady() {
        GLES20.glClearColor(0.02f, 0.03f, 0.06f, 1f);
        panelProgram = Gl.program(VS, FS);
        aPos = GLES20.glGetAttribLocation(panelProgram, "aPos");
        aUV = GLES20.glGetAttribLocation(panelProgram, "aUV");
        uMVP = GLES20.glGetUniformLocation(panelProgram, "uMVP");
        uTex = GLES20.glGetUniformLocation(panelProgram, "uTex");
        uTint = GLES20.glGetUniformLocation(panelProgram, "uTint");

        quadPos = Gl.fbuf(new float[]{
                -QUAD_HALF, -QUAD_HALF, 0f, QUAD_HALF, -QUAD_HALF, 0f,
                QUAD_HALF, QUAD_HALF, 0f, -QUAD_HALF, QUAD_HALF, 0f});
        // t=0 对应 Bitmap 第一行，所以左上顶点取 (0,0)，图才是正的
        quadUV = Gl.fbuf(new float[]{0f, 1f, 1f, 1f, 1f, 0f, 0f, 0f});
        cursorTex = IconTexture.createCursor();

        skybox = new Skybox();
        skybox.init();
        sphere360 = new SphereMesh(true);
        sphere360.init();
        sphere180 = new SphereMesh(true, (float) Math.PI);
        sphere180.init();
        video.initGL();

        buildScreen(SCREEN_LAUNCHER);
    }

    @Override
    public void onResize(int width, int height) {
    }

    @Override
    public void onFrame() {
        video.updateTexImage();                 // 每帧只调一次，必须在 GL 线程
        if (view != null) {
            view.getHeadForward(fwd);
            gaze.setHead(fwd);
        }
        gaze.update();

        if (gaze.modeChanged()) {
            if (gaze.usingHand()) {
                toast("手势模式：移动手掌移动准星，握拳点击");
            } else {
                toast("凝视模式：盯住图标约 1.2 秒");
            }
        }

        if (gaze.consumeTrigger()) {
            int h = gaze.hovered();
            if (h >= 0 && h < items.size()) {
                final Runnable a = items.get(h).action;
                ui.post(a);
            }
        }
    }

    @Override
    public void onDrawEye(StereoView.EyeFrame eye) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        boolean playing = (screen == SCREEN_VIDEO) && video.isReady();

        // ---- 背景：视频球 或 星空天空盒（先画、不写深度）----
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        if (playing) {
            SphereMesh m = video.is180() ? sphere180 : sphere360;
            m.draw(eye.vp, video.texId(), video.uvFor(eye.left));
        } else {
            skybox.draw(eye.vpNoTrans);
        }
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        // ---- 面板 + 准星 ----
        GLES20.glUseProgram(panelProgram);
        quadPos.position(0);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, 0, quadPos);
        GLES20.glEnableVertexAttribArray(aPos);
        quadUV.position(0);
        GLES20.glVertexAttribPointer(aUV, 2, GLES20.GL_FLOAT, false, 0, quadUV);
        GLES20.glEnableVertexAttribArray(aUV);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glUniform1i(uTex, 0);

        float p = gaze.progress();
        int hov = gaze.hovered();

        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            Matrix.setIdentityM(model, 0);
            Matrix.translateM(model, 0, it.x, it.y, GazeInput.PANEL_Z);
            float s = (i == hov) ? 1f + 0.08f * p : 1f;
            Matrix.scaleM(model, 0, s, s, s);
            Matrix.multiplyMM(tmp, 0, eye.vp, 0, model, 0);
            GLES20.glUniformMatrix4fv(uMVP, 1, false, tmp, 0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, it.tex);
            float t = (i == hov) ? 1f + 0.35f * p : 0.86f;
            GLES20.glUniform4f(uTint, t, t, t, 1f);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4);
        }

        // 手势模式下多画一圈低透明掌心环，给「谁在控制准星」一个明确反馈
        if (gaze.usingHand()) {
            drawCursor(eye.vp, 0.34f, 0.30f, 0.85f, 1f, 0.35f);
        }

        float k = CURSOR_Z / GazeInput.PANEL_Z;
        float cs = 0.16f + 0.06f * p;
        if (gaze.usingHand()) {
            drawCursor(eye.vp, gaze.x() * k, gaze.y() * k, cs, 0.30f, 0.85f, 1f, 0.95f);
        } else {
            drawCursor(eye.vp, gaze.x() * k, gaze.y() * k, cs,
                    1f - 0.6f * p, 0.45f + 0.55f * p, 0.32f, 0.95f);
        }

        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aUV);
    }

    private void drawCursor(float[] vp, float cs, float r, float g, float b, float a) {
        drawCursor(vp, gaze.x() * (CURSOR_Z / GazeInput.PANEL_Z),
                gaze.y() * (CURSOR_Z / GazeInput.PANEL_Z), cs, r, g, b, a);
    }

    private void drawCursor(float[] vp, float x, float y, float cs,
                            float r, float g, float b, float a) {
        Matrix.setIdentityM(model, 0);
        Matrix.translateM(model, 0, x, y, CURSOR_Z);
        Matrix.scaleM(model, 0, cs, cs, cs);
        Matrix.multiplyMM(tmp, 0, vp, 0, model, 0);
        GLES20.glUniformMatrix4fv(uMVP, 1, false, tmp, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, cursorTex);
        GLES20.glUniform4f(uTint, r, g, b, a);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, 4);
    }

    // ==================== 屏幕构建（GL 线程）====================

    private void buildScreen(int s) {
        screen = s;
        items.clear();
        float[] X = new float[16];
        float[] Y = new float[16];
        int n = 0;

        if (s == SCREEN_LAUNCHER) {
            add(items, X, Y, n++, 0xFFE53935, "看片", -1.15f, 0.85f, new Runnable() {
                @Override public void run() { openLibrary(); }
            });
            add(items, X, Y, n++, 0xFF1E88E5, "上网", 0f, 0.85f, new Runnable() {
                @Override public void run() { openBrowser(); }
            });
            add(items, X, Y, n++, 0xFF43A047, "相册", 1.15f, 0.85f, new Runnable() {
                @Override public void run() { openGallery(); }
            });
            add(items, X, Y, n++, 0xFF8E24AA, "时钟", -1.15f, -0.15f, new Runnable() {
                @Override public void run() { showClock(); }
            });
            add(items, X, Y, n++, 0xFF546E7A, "设置", 0f, -0.15f, new Runnable() {
                @Override public void run() { switchScreen(SCREEN_SETTINGS); }
            });
            add(items, X, Y, n++, 0xFFF4511E, "关于", 1.15f, -0.15f, new Runnable() {
                @Override public void run() { showAbout(); }
            });

        } else if (s == SCREEN_LIBRARY) {
            int count = Math.min(6, videos.size());
            float[] cx = {-1.15f, 0f, 1.15f};
            for (int i = 0; i < count; i++) {
                final VideoEntry v = videos.get(i);
                String label = shortName(v.name, 3);
                add(items, X, Y, n++, 0xFF3949AB, label, cx[i % 3],
                        (i < 3 ? 0.85f : -0.15f), new Runnable() {
                            @Override public void run() { playVideo(v.uri); }
                        });
            }
            if (count == 0) {
                add(items, X, Y, n++, 0xFF757575, "无片源", 0f, 0.85f, new Runnable() {
                    @Override public void run() { toast("没读到视频，检查存储权限或拷一个到 Movies/"); }
                });
            }
            add(items, X, Y, n++, 0xFF455A64, "返回", 0f, -1.15f, new Runnable() {
                @Override public void run() { switchScreen(SCREEN_LAUNCHER); }
            });

        } else if (s == SCREEN_SETTINGS) {
            add(items, X, Y, n++, 0xFF00897B, "回正", -1.15f, 0.85f, new Runnable() {
                @Override public void run() {
                    if (view != null) view.recenter();
                    toast("已把当前朝向设为正前方");
                }
            });
            add(items, X, Y, n++, 0xFF5E35B1, "镜像", 0f, 0.85f, new Runnable() {
                @Override public void run() {
                    gaze.setMirrorHand(!gaze.isMirrorHand());
                    toast("手势镜像：" + (gaze.isMirrorHand() ? "开" : "关"));
                }
            });
            add(items, X, Y, n++, 0xFF1E88E5, "格式", 1.15f, 0.85f, new Runnable() {
                @Override public void run() {
                    video.cycleFormat();
                    toast("视频格式：" + video.getFormat());
                }
            });
            add(items, X, Y, n++, 0xFFD84315, "手势", -0.6f, -0.15f, new Runnable() {
                @Override public void run() {
                    gestureEnabled = !gestureEnabled;
                    if (!gestureEnabled) gaze.setGestureEnabled(false);
                    toast("手势输入：" + (gestureEnabled ? "开" : "关（仅凝视）"));
                }
            });
            add(items, X, Y, n++, 0xFF455A64, "返回", 0.6f, -0.15f, new Runnable() {
                @Override public void run() { switchScreen(SCREEN_LAUNCHER); }
            });

        } else { // SCREEN_VIDEO
            add(items, X, Y, n++, 0xFF455A64, "返回", -1.3f, -1.2f, new Runnable() {
                @Override public void run() {
                    if (video.isPlaying()) video.togglePause();
                    switchScreen(SCREEN_LIBRARY);
                }
            });
            add(items, X, Y, n++, 0xFF2E7D32, "播放", 1.3f, -1.2f, new Runnable() {
                @Override public void run() {
                    video.togglePause();
                    toast(video.isPlaying() ? "继续播放" : "已暂停");
                }
            });
            add(items, X, Y, n++, 0xFF1565C0, "格式", -1.3f, 1.25f, new Runnable() {
                @Override public void run() {
                    video.cycleFormat();
                    toast("视频格式：" + video.getFormat());
                }
            });
            add(items, X, Y, n++, 0xFF6A1B9A, "翻转", 1.3f, 1.25f, new Runnable() {
                @Override public void run() {
                    video.setMirrorU(!video.isMirrorU());
                    toast("画面左右镜像：" + (video.isMirrorU() ? "开" : "关"));
                }
            });
        }

        targetX = java.util.Arrays.copyOf(X, n);
        targetY = java.util.Arrays.copyOf(Y, n);
        gaze.setTargets(targetX, targetY);
    }

    private void add(List<Item> list, float[] X, float[] Y, int i,
                     int bg, String label, float x, float y, Runnable action) {
        String key = bg + "_" + label + "_" + (label.length() > 2 ? 56f : 88f);
        Integer t = texCache.get(key);
        if (t == null) {
            t = IconTexture.create(bg, label, label.length() > 2 ? 56f : 88f);
            texCache.put(key, t);
        }
        list.add(new Item(t, x, y, action));
        X[i] = x;
        Y[i] = y;
    }

    private void switchScreen(final int s) {
        if (view != null) {
            view.queueEvent(new Runnable() {
                @Override public void run() { buildScreen(s); }
            });
        }
    }

    // ==================== 动作 ====================

    private void openLibrary() {
        ui.post(new Runnable() {
            @Override public void run() {
                final List<VideoEntry> list = loadVideos();
                if (view != null) {
                    view.queueEvent(new Runnable() {
                        @Override public void run() {
                            videos.clear();
                            videos.addAll(list);
                            buildScreen(SCREEN_LIBRARY);
                        }
                    });
                }
            }
        });
    }

    private List<VideoEntry> loadVideos() {
        List<VideoEntry> out = new ArrayList<VideoEntry>();
        Cursor c = null;
        try {
            String[] proj = {MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME};
            c = ctx.getContentResolver().query(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                    MediaStore.Video.Media.DATE_ADDED + " DESC");
            if (c == null) return out;
            int idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
            int nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
            while (c.moveToNext() && out.size() < 6) {
                VideoEntry v = new VideoEntry();
                v.name = c.getString(nameCol);
                long id = c.getLong(idCol);
                v.uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id);
                out.add(v);
            }
        } catch (Exception e) {
            toast("读取媒体库失败：" + e.getMessage());
        } finally {
            if (c != null) c.close();
        }
        return out;
    }

    private void playVideo(final Uri u) {
        ui.post(new Runnable() {
            @Override public void run() {
                video.play(ctx, u);
                toast("正在加载视频…（格式不对就在角落点『格式』切换）");
                switchScreen(SCREEN_VIDEO);
            }
        });
    }

    private void openBrowser() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.baidu.com"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception e) {
            toast("没有可用的浏览器");
        }
    }

    private void openGallery() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setType("image/*");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
        } catch (Exception e) {
            toast("没有可用的相册应用");
        }
    }

    private void showClock() {
        toast(android.text.format.DateFormat.format("HH:mm  MM/dd", new java.util.Date()).toString());
    }

    private void showAbout() {
        toast("MiniVR Launcher v2 · 零依赖 / 360球面播放 / Camera2手势 · 纯 Java + GLES2");
    }

    // ==================== HandTracker.Callback ====================

    @Override
    public void onGesture(HandDetector.Gesture g) {
        if (gestureEnabled && g != null) gaze.setGesture(g.copy());
    }

    @Override
    public void onStatus(String msg) {
        toast(msg);
    }

    private void toast(final String s) {
        ui.post(new Runnable() {
            @Override public void run() {
                Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private static String shortName(String name, int max) {
        if (name == null) return "片";
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        return name.length() > max ? name.substring(0, max) : name;
    }

    // ==================== 生命周期 ====================

    /** Activity.onDestroy 用：不碰 GL 对象。 */
    public void releasePlayerOnly() {
        video.releasePlayerOnly();
    }

    /** GL 线程调用；本工程默认交给 EGL 上下文销毁统一回收，不主动调。 */
    public void release() {
        video.release();
        if (skybox != null) skybox.release();
        if (sphere360 != null) sphere360.release();
        if (sphere180 != null) sphere180.release();
    }
}
